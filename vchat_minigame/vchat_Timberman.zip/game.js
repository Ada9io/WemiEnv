import './js/libs/weapp-adapter'
import Main from './js/main'

new Main()